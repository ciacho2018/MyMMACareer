const organizations = [
  {
    id: "local",
    name: "Local Fight League",
    tier: 1,
    rankingSize: 10,
    statBase: 56,
    minPopularity: 0,
    minWins: 0,
    baseShow: 250,
    baseWin: 175,
    contractLength: 4,
    titleShowBonus: 180,
    titleWinBonus: 120
  },
  {
    id: "regional",
    name: "European Combat Series",
    tier: 2,
    rankingSize: 10,
    statBase: 68,
    minPopularity: 30,
    minWins: 5,
    baseShow: 900,
    baseWin: 650,
    contractLength: 5,
    titleShowBonus: 500,
    titleWinBonus: 350
  },
  {
    id: "world",
    name: "World Crown MMA",
    tier: 3,
    rankingSize: 15,
    statBase: 80,
    minPopularity: 70,
    minWins: 12,
    baseShow: 3200,
    baseWin: 2400,
    contractLength: 6,
    titleShowBonus: 1800,
    titleWinBonus: 1200
  }
];

const managersPool = [
  {
    id: "oldfox",
    name: "Piotr 'Old Fox' Makowski",
    style: "Negocjator",
    signingFee: 900,
    cutPercent: 12,
    contractBonus: 0.16,
    popularityBonus: 0.05,
    trainingBonus: 0.0,
    socialBonus: 0.02
  },
  {
    id: "hypequeen",
    name: "Monika 'Hype Queen' Nowak",
    style: "Marketing",
    signingFee: 1200,
    cutPercent: 15,
    contractBonus: 0.09,
    popularityBonus: 0.16,
    trainingBonus: 0.0,
    socialBonus: 0.18
  },
  {
    id: "coachagent",
    name: "Andrzej 'Coach-Agent' Domański",
    style: "Rozwój sportowy",
    signingFee: 1000,
    cutPercent: 13,
    contractBonus: 0.07,
    popularityBonus: 0.03,
    trainingBonus: 0.18,
    socialBonus: 0.0
  },
  {
    id: "shark",
    name: "Victor 'The Shark' Leone",
    style: "Top level deals",
    signingFee: 2200,
    cutPercent: 18,
    contractBonus: 0.24,
    popularityBonus: 0.08,
    trainingBonus: 0.05,
    socialBonus: 0.05
  }
];

const campsPool = [
  { id: "standard", name: "Standard Camp", cost: 0, durationWeeks: 1, bonuses: {}, note: "Bez dodatkowych bonusów." },
  { id: "boxinglab", name: "Boxing Lab", cost: 450, durationWeeks: 2, bonuses: { striking: 5, defense: 2 }, note: "+Striking, +Defense" },
  { id: "wrestlingforge", name: "Wrestling Forge", cost: 500, durationWeeks: 2, bonuses: { grappling: 3, takedown: 5 }, note: "+Grappling, +Takedown" },
  { id: "altitude", name: "Altitude Camp", cost: 520, durationWeeks: 2, bonuses: { stamina: 5, defense: 1 }, note: "+Cardio, +Defense" },
  { id: "champcamp", name: "Champ Camp", cost: 900, durationWeeks: 3, bonuses: { striking: 3, grappling: 3, takedown: 3, defense: 3, stamina: 3 }, note: "Wszechstronny, drogi obóz." }
];

const firstNames = ["Mike", "Carlos", "Ivan", "Alex", "Tyrone", "Luca", "Khalid", "Rafael", "Ben", "Damian", "Victor", "Marek", "Nate", "Leo", "Omar"];
const lastNames = ["Johnson", "Silva", "Petrov", "Novak", "Carter", "Moretti", "Hassan", "Costa", "Murphy", "Woods", "Romanov", "Nowicki", "Mendes", "Keller", "Santos"];
const nicknames = ["The Axe", "No Mercy", "Steel Chin", "The Wolf", "Ice Hand", "Pitbull", "Crusher", "Ghost", "Bulldozer", "Ruthless"];

function getOrg(id) {
  return organizations.find((org) => org.id === id);
}

function buildContract(org, moneyModifier = 1, lengthBonus = 0, signedWeek = 1) {
  return {
    orgId: org.id,
    showMoney: Math.round(org.baseShow * moneyModifier),
    winBonus: Math.round(org.baseWin * moneyModifier),
    fightsLeft: org.contractLength + lengthBonus,
    totalFights: org.contractLength + lengthBonus,
    signedWeek
  };
}

const career = {
  started: false,
  retired: false,
  week: 1,
  organizationsVisited: ["local"],
  titlesHistory: [],
  manager: null,
  injury: null,
  nextFightCampId: "standard",
  fighter: {
    name: 'Jan "The Hammer" Kowalski',
    age: 22,
    striking: 69,
    grappling: 64,
    takedown: 66,
    defense: 65,
    stamina: 71,
    health: 100,
    currentHealth: 100,
    currentStamina: 71,
    popularity: 8,
    followers: 3500,
    hype: 5,
    money: 1200,
    wins: 0,
    losses: 0,
    draws: 0,
    koWins: 0,
    subWins: 0,
    decWins: 0,
    koLosses: 0,
    subLosses: 0,
    decLosses: 0,
    currentOrgId: "local",
    rank: 10,
    isChampion: false,
    currentTitleDefenses: 0,
    totalTitleWins: 0,
    totalTitleDefenses: 0,
    injuryCount: 0,
    weeksActive: 0
  },
  currentContract: buildContract(getOrg("local"), 0.9, 0, 1)
};

let currentRound = 1;
let currentMaxRounds = 3;
let fightInterval = null;
let offeredBout = null;
let currentBout = null;
let marketOffers = [];
let managerOffers = [];
let careerLogElement = null;
let fightLogElement = null;

function $(id) {
  return document.getElementById(id);
}

function setText(id, value) {
  const el = $(id);
  if (el) el.textContent = value;
}

function show(id) {
  const el = $(id);
  if (el) el.classList.remove("hidden");
}

function hide(id) {
  const el = $(id);
  if (el) el.classList.add("hidden");
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function clampStat(value) {
  return clamp(value, 40, 99);
}

function randomInt(min, max) {
  return Math.floor(min + Math.random() * (max - min + 1));
}

function randomRange(min, max) {
  return min + Math.random() * (max - min);
}

function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function averageCombatStats(fighter) {
  return (fighter.striking + fighter.grappling + fighter.takedown + fighter.defense + fighter.stamina) / 5;
}

function getCurrentOrg() {
  return getOrg(career.fighter.currentOrgId);
}

function getPrimeLabel(age) {
  if (age <= 25) return "Prospect";
  if (age <= 31) return "Prime";
  if (age <= 35) return "Veteran";
  return "Late career";
}

function renderTitlesHistory() {
  if (!career.titlesHistory.length) return "Brak";
  return career.titlesHistory.join(" | ");
}

function renderOrganizationsHistory() {
  return career.organizationsVisited.map((id) => getOrg(id).name).join(", ");
}

function showScreen(screenId) {
  document.querySelectorAll(".screen").forEach((screen) => screen.classList.add("hidden"));
  const target = $(screenId);
  if (target) target.classList.remove("hidden");
}

function addCareerLog(text) {
  if (!careerLogElement) return;
  const p = document.createElement("p");
  p.className = "log-entry";
  p.textContent = text;
  careerLogElement.prepend(p);
}

function addFightLog(text) {
  if (!fightLogElement) return;
  const p = document.createElement("p");
  p.className = "log-entry";
  p.textContent = text;
  fightLogElement.appendChild(p);
  fightLogElement.scrollTop = fightLogElement.scrollHeight;
}

function initLogs() {
  careerLogElement = $("career-log");
  fightLogElement = $("fight-log");
}

function getRankLabel() {
  const fighter = career.fighter;
  const org = getCurrentOrg();
  if (fighter.isChampion) return `Mistrz ${org.name}`;
  return `#${fighter.rank} / ${org.rankingSize}`;
}

function getGoalText() {
  const fighter = career.fighter;
  const org = getCurrentOrg();
  if (career.injury && career.injury.weeksLeft > 0) {
    return `Wrócić po kontuzji (${career.injury.weeksLeft} tyg. leczenia).`;
  }
  if (!career.currentContract) {
    return "Podpisać nowy kontrakt.";
  }
  if (fighter.isChampion) {
    return `Bonić pasa w ${org.name}.`;
  }
  if (fighter.rank <= 1) {
    return `Zdobyć title shota w ${org.name}.`;
  }
  if (fighter.rank <= 3) {
    return "Zostać pretendentem nr 1.";
  }
  return `Wejść wyżej w rankingu ${org.name}.`;
}

function updateCareerUI() {
  const f = career.fighter;
  const org = getCurrentOrg();
  const injuryText = career.injury && career.injury.weeksLeft > 0
    ? `${career.injury.name} (${career.injury.weeksLeft} tyg.)`
    : "Brak";

  setText("fighter-name", f.name);
  setText("career-week", career.week);
  setText("fighter-age", f.age);
  setText("fighter-prime", getPrimeLabel(f.age));
  setText("fighter-record", `${f.wins}-${f.losses}-${f.draws}`);
  setText("wins-ko", f.koWins);
  setText("wins-sub", f.subWins);
  setText("wins-dec", f.decWins);
  setText("losses-ko", f.koLosses);
  setText("losses-sub", f.subLosses);
  setText("losses-dec", f.decLosses);
  setText("fighter-money", Math.floor(f.money));
  setText("fighter-health", Math.floor(f.currentHealth));
  setText("fighter-stamina", Math.floor(f.currentStamina));
  setText("fighter-injury", injuryText);

  setText("fighter-org", org.name);
  setText("fighter-rank", getRankLabel());
  setText("fighter-goal", getGoalText());

  if (career.currentContract) {
    setText("fighter-contract", "Aktywny");
    setText("contract-show", career.currentContract.showMoney);
    setText("contract-win", career.currentContract.winBonus);
    setText("contract-fights", career.currentContract.fightsLeft);
  } else {
    setText("fighter-contract", "Brak aktywnego kontraktu");
    setText("contract-show", "-");
    setText("contract-win", "-");
    setText("contract-fights", "-");
  }

  setText("fighter-manager", career.manager ? career.manager.name : "Brak menedżera");
  setText("manager-cut", career.manager ? `${career.manager.cutPercent}%` : "0%");
  setText("fighter-popularity", f.popularity);
  setText("fighter-followers", Math.floor(f.followers));
  setText("fighter-hype", f.hype);

  setText("stat-striking", f.striking);
  setText("stat-grappling", f.grappling);
  setText("stat-takedown", f.takedown);
  setText("stat-defense", f.defense);
  setText("stat-cardio", f.stamina);

  setText("current-belt", f.isChampion ? `Mistrz ${org.name}` : "Brak pasa");
  setText("current-defenses", f.currentTitleDefenses);
  setText("total-title-wins", f.totalTitleWins);
  setText("total-defenses", f.totalTitleDefenses);
  setText("org-history", renderOrganizationsHistory());
  setText("belt-history", renderTitlesHistory());
}

function updateFightUI() {
  if (!currentBout) return;
  const player = career.fighter;
  const enemy = currentBout.opponent;

  setText("fight-org", getCurrentOrg().name);
  setText("fight-type", currentBout.label);
  setText("round", currentRound);
  setText("max-rounds", currentMaxRounds);
  setText("fight-player-name", player.name);
  setText("fight-enemy-name", enemy.name);
  setText("fight-player-health", Math.max(0, Math.floor(player.currentHealth)));
  setText("fight-enemy-health", Math.max(0, Math.floor(enemy.currentHealth)));
  setText("fight-player-stamina", Math.max(0, Math.floor(player.currentStamina)));
  setText("fight-enemy-stamina", Math.max(0, Math.floor(enemy.currentStamina)));

  const pBar = $("player-health-bar");
  const eBar = $("enemy-health-bar");
  if (pBar) pBar.style.width = `${clamp(player.currentHealth, 0, 100)}%`;
  if (eBar) eBar.style.width = `${clamp(enemy.currentHealth, 0, 100)}%`;
}

function startCareer() {
  initLogs();
  showScreen("career-screen");
  if (!career.started) {
    career.started = true;
    addCareerLog("Rozpoczynasz karierę w Local Fight League.");
    addCareerLog("Walki są w pełni automatyczne. Ty planujesz trening, wybierasz obozy, kontrakty i menedżerów.");
  }
  updateCareerUI();
}

function getTrainingGain() {
  const age = career.fighter.age;
  let gain = 2;
  if (age <= 28) {
    gain = Math.random() < 0.6 ? 2 : 3;
  } else if (age <= 34) {
    gain = Math.random() < 0.65 ? 2 : 1;
  } else {
    gain = 1;
  }
  if (career.manager) {
    gain = Math.max(1, Math.round(gain * (1 + career.manager.trainingBonus)));
  }
  return gain;
}

function processInjuryHealingOneWeek() {
  if (!career.injury) return;
  career.injury.weeksLeft -= 1;
  if (career.injury.weeksLeft <= 0) {
    addCareerLog(`Wracasz do pełnych treningów po kontuzji: ${career.injury.name}.`);
    career.injury = null;
  }
}

function handleBirthday() {
  const f = career.fighter;
  f.age += 1;
  addCareerLog(`Mija rok kariery. Kończysz ${f.age} lat.`);
  if (f.age >= 33) {
    const stats = ["striking", "grappling", "takedown", "defense", "stamina"];
    const declineCount = f.age >= 37 ? 2 : 1;
    for (let i = 0; i < declineCount; i += 1) {
      const stat = randomItem(stats);
      f[stat] = clampStat(f[stat] - 1);
    }
    addCareerLog("Wiek zaczyna odbijać się na Twoich parametrach.");
  }
}

function advanceWeek(count = 1) {
  for (let i = 0; i < count; i += 1) {
    if (career.retired) return;
    career.week += 1;
    career.fighter.weeksActive += 1;
    processInjuryHealingOneWeek();
    if ((career.week - 1) % 52 === 0) {
      handleBirthday();
      if (career.retired) return;
    }
    if (!career.currentContract && career.week % 4 === 0) {
      career.fighter.popularity = Math.max(0, career.fighter.popularity - 1);
      addCareerLog("Brak aktywności powoduje lekki spadek popularności.");
    }
  }
}

function trainStat(stat) {
  if (career.retired) return;
  if (career.injury && career.injury.weeksLeft > 0) {
    addCareerLog("Masz aktywną kontuzję. Trening sportowy nie jest teraz możliwy.");
    return;
  }
  const gain = getTrainingGain();
  career.fighter[stat] = clampStat(career.fighter[stat] + gain);
  career.fighter.currentStamina = clamp(career.fighter.currentStamina - randomInt(6, 12), 20, 100);
  career.fighter.currentHealth = clamp(career.fighter.currentHealth - randomInt(1, 4), 40, 100);
  advanceWeek(1);
  addCareerLog(`Trening ${labelForStat(stat)} daje +${gain}.`);
  updateCareerUI();
  checkCareerEndConditions();
}

function labelForStat(stat) {
  const labels = {
    striking: "stójki",
    grappling: "grapplingu",
    takedown: "obaleń",
    defense: "obrony",
    stamina: "kondycji"
  };
  return labels[stat] || stat;
}

function trainCardio() {
  if (career.retired) return;
  if (career.injury && career.injury.weeksLeft > 0) {
    addCareerLog("Masz aktywną kontuzję. Zrób rehab albo odpoczynek.");
    return;
  }
  const gain = getTrainingGain();
  career.fighter.stamina = clampStat(career.fighter.stamina + gain);
  career.fighter.currentStamina = clamp(career.fighter.currentStamina + randomInt(2, 8), 20, career.fighter.stamina);
  career.fighter.currentHealth = clamp(career.fighter.currentHealth - randomInt(0, 2), 40, 100);
  advanceWeek(1);
  addCareerLog(`Pracujesz nad kondycją. Cardio +${gain}.`);
  updateCareerUI();
}

function restFighter() {
  if (career.retired) return;
  const healWeeks = career.injury ? 2 : 1;
  advanceWeek(healWeeks);
  career.fighter.currentHealth = clamp(career.fighter.currentHealth + randomInt(10, 18), 0, 100);
  career.fighter.currentStamina = clamp(career.fighter.currentStamina + randomInt(8, 15), 0, career.fighter.stamina);
  addCareerLog(career.injury ? "Wchodzisz w rehab i oszczędzasz organizm." : "Robisz tydzień regeneracji.");
  updateCareerUI();
}

function socialAction(type) {
  if (career.retired) return;
  let followersGain = 0;
  let popGain = 0;
  let hypeGain = 0;

  if (type === "highlight") {
    followersGain = randomInt(250, 550);
    popGain = 2;
    hypeGain = 2;
    addCareerLog("Publikujesz highlight reel. Ludzie lubią brutalne nokauty i dobre akcje.");
  } else if (type === "callout") {
    followersGain = randomInt(180, 700);
    popGain = 1;
    hypeGain = 4;
    addCareerLog("Robisz głośny callout rywala. Wokół Twojego nazwiska robi się szum.");
  } else {
    followersGain = randomInt(140, 420);
    popGain = 2;
    hypeGain = 1;
    addCareerLog("Nagrałeś vlog i wywiad. Fani lepiej Cię poznają.");
  }

  if (career.manager) {
    followersGain = Math.round(followersGain * (1 + career.manager.socialBonus));
    popGain = Math.max(1, Math.round(popGain * (1 + career.manager.popularityBonus)));
  }

  career.fighter.followers += followersGain;
  career.fighter.popularity = clamp(career.fighter.popularity + popGain, 0, 100);
  career.fighter.hype = clamp(career.fighter.hype + hypeGain, 0, 100);
  advanceWeek(1);
  updateCareerUI();
}

function generateOpponentName() {
  return `${randomItem(firstNames)} "${randomItem(nicknames)}" ${randomItem(lastNames)}`;
}

function getBoutLabel(type) {
  if (type === "title-shot") return "Walka o pas";
  if (type === "title-defense") return "Obrona pasa";
  if (type === "eliminator") return "Eliminator do title shota";
  return "Walka rankingowa";
}

function generateOpponent(org, type) {
  const f = career.fighter;
  let targetRank = org.rankingSize;

  if (type === "title-shot") {
    targetRank = 0;
  } else if (type === "title-defense") {
    targetRank = Math.random() < 0.5 ? 1 : 2;
  } else if (type === "eliminator") {
    targetRank = Math.max(1, f.rank - 1);
  } else {
    const minRank = Math.max(1, f.rank - 2);
    const maxRank = Math.min(org.rankingSize, f.rank + 1);
    targetRank = randomInt(minRank, maxRank);
  }

  const avgPlayer = averageCombatStats(f);
  const rankBoost = targetRank === 0 ? org.rankingSize + 3 : (org.rankingSize - targetRank + 1);
  let base = org.statBase + rankBoost * 1.4;

  if (type === "title-shot") base += 6;
  if (type === "title-defense") base += 4;
  if (type === "eliminator") base += 2;
  base = Math.max(base, avgPlayer + (targetRank > 0 && targetRank < f.rank ? 2 : 0));

  const genStat = () => clampStat(Math.round(base + randomRange(-6, 6)));
  const stamina = clampStat(Math.round(base + randomRange(-4, 8)));

  return {
    name: generateOpponentName(),
    striking: genStat(),
    grappling: genStat(),
    takedown: genStat(),
    defense: genStat(),
    stamina,
    health: 100,
    currentHealth: 100,
    currentStamina: stamina,
    rank: targetRank,
    isChampion: targetRank === 0
  };
}

function renderCampOptions() {
  const container = $("camp-options");
  if (!container || !offeredBout) return;
  container.innerHTML = "";

  campsPool.forEach((camp) => {
    const card = document.createElement("div");
    card.className = "choice-card" + (camp.id === career.nextFightCampId ? " selected" : "");
    const affordable = career.fighter.money >= camp.cost;
    card.innerHTML = `
      <strong>${camp.name}</strong>
      <p class="small-text">Koszt: $${camp.cost} | Długość: ${camp.durationWeeks} tyg.</p>
      <p class="small-text">${camp.note}</p>
      <button ${!affordable ? "disabled" : ""} onclick="selectCamp('${camp.id}')">${affordable ? "Wybierz" : "Za drogi"}</button>
    `;
    container.appendChild(card);
  });

  const currentCamp = campsPool.find((camp) => camp.id === career.nextFightCampId);
  setText("selected-camp-summary", currentCamp ? `Wybrany obóz: ${currentCamp.name}.` : "Wybrany obóz: brak.");
}

function selectCamp(campId) {
  career.nextFightCampId = campId;
  renderCampOptions();
}

function offerFight() {
  if (career.retired) return;
  const f = career.fighter;
  const org = getCurrentOrg();

  if (career.injury && career.injury.weeksLeft > 0) {
    addCareerLog("Nie możesz przyjąć walki, bo leczysz kontuzję.");
    return;
  }
  if (!career.currentContract) {
    addCareerLog("Nie masz kontraktu. Najpierw wejdź na rynek kontraktowy.");
    return;
  }
  if (f.currentHealth < 55 || f.currentStamina < 45) {
    addCareerLog("Jesteś za bardzo zajechany. Odpocznij albo potrenuj cardio.");
    return;
  }

  let type = "regular";
  if (f.isChampion) {
    type = "title-defense";
  } else if (f.rank <= 1) {
    type = "title-shot";
  } else if (f.rank <= 3 && Math.random() < 0.45) {
    type = "eliminator";
  }

  const opponent = generateOpponent(org, type);
  const titleFight = type === "title-shot" || type === "title-defense";
  const showMoney = career.currentContract.showMoney + (titleFight ? org.titleShowBonus : type === "eliminator" ? Math.floor(org.titleShowBonus * 0.35) : 0);
  const winBonus = career.currentContract.winBonus + (titleFight ? org.titleWinBonus : type === "eliminator" ? Math.floor(org.titleWinBonus * 0.25) : 0);

  offeredBout = {
    type,
    label: getBoutLabel(type),
    opponent,
    rounds: titleFight ? 5 : 3,
    showMoney,
    winBonus,
    playerDamage: 0,
    enemyDamage: 0,
    finishMethod: null
  };

  setText("offer-bout-type", offeredBout.label);
  setText("offer-org", org.name);
  setText("offer-name", opponent.name);
  setText("offer-rank", opponent.isChampion ? "Mistrz organizacji" : `#${opponent.rank} rankingu`);
  setText("offer-striking", opponent.striking);
  setText("offer-grappling", opponent.grappling);
  setText("offer-takedown", opponent.takedown);
  setText("offer-defense", opponent.defense);
  setText("offer-cardio", opponent.stamina);
  setText("offer-show", offeredBout.showMoney);
  setText("offer-win", offeredBout.winBonus);
  renderCampOptions();
  show("fight-offer-panel");
  addCareerLog(`Pojawia się oferta walki: ${offeredBout.label.toLowerCase()} w ${org.name}.`);
}

function acceptFight() {
  if (!offeredBout) return;
  const camp = campsPool.find((item) => item.id === career.nextFightCampId) || campsPool[0];
  if (career.fighter.money < camp.cost) {
    addCareerLog("Nie masz dość pieniędzy na ten obóz.");
    return;
  }

  career.fighter.money -= camp.cost;
  career.fighter.currentStamina = clamp(career.fighter.currentStamina + (camp.bonuses.stamina || 0), 0, 100);
  career.fighter.currentHealth = clamp(career.fighter.currentHealth + 6, 0, 100);

  advanceWeek(camp.durationWeeks);

  currentBout = offeredBout;
  currentBout.camp = camp;
  currentBout.opponent.currentHealth = 100;
  currentBout.opponent.currentStamina = currentBout.opponent.stamina;
  offeredBout = null;
  hide("fight-offer-panel");
  updateCareerUI();
  startFight();
}

function declineFight() {
  offeredBout = null;
  hide("fight-offer-panel");
  career.fighter.popularity = Math.max(0, career.fighter.popularity - 1);
  career.fighter.hype = Math.max(0, career.fighter.hype - 1);
  advanceWeek(1);
  addCareerLog("Odrzucasz ofertę walki.");
  updateCareerUI();
}

function scoutMarket() {
  const f = career.fighter;
  const currentOrg = getCurrentOrg();
  const currentTier = currentOrg.tier;
  const managerBonus = career.manager ? career.manager.contractBonus : 0;

  marketOffers = organizations
    .filter((org) => org.tier >= currentTier || !career.currentContract)
    .filter((org) => f.popularity >= org.minPopularity && f.wins >= org.minWins)
    .map((org) => {
      const moneyModifier = 1 + (f.popularity / 220) + (managerBonus * 0.7) + (org.id === currentOrg.id ? 0.07 : 0);
      const lengthBonus = f.popularity >= 65 ? 1 : 0;
      return {
        orgId: org.id,
        contract: buildContract(org, moneyModifier, lengthBonus, career.week)
      };
    });

  const container = $("contract-offers");
  container.innerHTML = "";

  if (!marketOffers.length) {
    container.innerHTML = `<div class="offer-card"><p>Na razie nikt nie składa Ci nowej oferty. Zbieraj zwycięstwa i popularność.</p></div>`;
  } else {
    marketOffers.forEach((offer) => {
      const org = getOrg(offer.orgId);
      const card = document.createElement("div");
      card.className = "offer-card";
      card.innerHTML = `
        <strong>${org.name}</strong>
        <p class="small-text">Show money: $${offer.contract.showMoney}</p>
        <p class="small-text">Bonus za wygraną: $${offer.contract.winBonus}</p>
        <p class="small-text">Liczba walk: ${offer.contract.fightsLeft}</p>
        <div class="offer-actions">
          <button onclick="signContract('${offer.orgId}')">Podpisz kontrakt</button>
        </div>
      `;
      container.appendChild(card);
    });
  }

  show("contract-market-panel");
}

function signContract(orgId) {
  const match = marketOffers.find((offer) => offer.orgId === orgId);
  if (!match) return;

  const org = getOrg(orgId);
  career.currentContract = match.contract;
  career.fighter.currentOrgId = orgId;
  career.fighter.rank = org.rankingSize;
  career.fighter.isChampion = false;
  career.fighter.currentTitleDefenses = 0;
  if (!career.organizationsVisited.includes(orgId)) {
    career.organizationsVisited.push(orgId);
  }

  addCareerLog(`Podpisujesz kontrakt z ${org.name}.`);
  hide("contract-market-panel");
  updateCareerUI();
}

function closeContractMarket() {
  hide("contract-market-panel");
}

function openManagerMarket() {
  managerOffers = [...managersPool];
  const container = $("manager-offers");
  container.innerHTML = "";

  managerOffers.forEach((manager) => {
    const card = document.createElement("div");
    card.className = "offer-card";
    card.innerHTML = `
      <strong>${manager.name}</strong>
      <p class="small-text">Styl: ${manager.style}</p>
      <p class="small-text">Opłata za podpis: $${manager.signingFee}</p>
      <p class="small-text">Prowizja: ${manager.cutPercent}%</p>
      <p class="small-text">Bonus kontraktowy: +${Math.round(manager.contractBonus * 100)}%</p>
      <div class="offer-actions">
        <button onclick="hireManager('${manager.id}')">Zatrudnij</button>
      </div>
    `;
    container.appendChild(card);
  });

  show("manager-market-panel");
}

function hireManager(managerId) {
  const manager = managersPool.find((item) => item.id === managerId);
  if (!manager) return;
  if (career.fighter.money < manager.signingFee) {
    addCareerLog("Nie stać Cię teraz na tego menedżera.");
    return;
  }

  career.fighter.money -= manager.signingFee;
  career.manager = manager;
  addCareerLog(`Podpisujesz współpracę z menedżerem: ${manager.name}.`);
  hide("manager-market-panel");
  updateCareerUI();
}

function closeManagerMarket() {
  hide("manager-market-panel");
}

function getFightStat(fighter, stat) {
  let value = fighter[stat];
  const camp = currentBout && currentBout.camp ? currentBout.camp : null;
  if (camp && camp.bonuses[stat]) {
    value += camp.bonuses[stat];
  }
  return clampStat(value);
}

function chooseAction(attacker, defender) {
  const strikingBias = attacker.striking + attacker.defense * 0.2;
  const grapplingBias = attacker.grappling + attacker.takedown * 0.5;
  const cardioBias = attacker.currentStamina * 0.3;
  const total = strikingBias + grapplingBias + cardioBias;
  const roll = Math.random() * total;

  if (roll < strikingBias) {
    return { type: "strike", attack: attacker.striking, defense: defender.defense };
  }
  if (roll < strikingBias + grapplingBias) {
    return { type: "grapple", attack: attacker.grappling + attacker.takedown * 0.4, defense: defender.grappling + defender.defense * 0.3 };
  }
  return { type: "pressure", attack: attacker.striking * 0.7 + attacker.stamina * 0.6, defense: defender.defense + defender.stamina * 0.3 };
}

function resolveExchange(attacker, defender, attackerName, defenderName) {
  const action = chooseAction(attacker, defender);
  const successScore = action.attack + attacker.currentStamina * 0.35 + randomRange(-8, 8);
  const defenseScore = action.defense + defender.currentStamina * 0.25 + randomRange(-8, 8);

  attacker.currentStamina = clamp(attacker.currentStamina - randomInt(6, 11), 0, 100);
  defender.currentStamina = clamp(defender.currentStamina - randomInt(3, 8), 0, 100);

  if (successScore <= defenseScore) {
    addFightLog(`${attackerName} atakuje, ale ${defenderName} dobrze reaguje.`);
    return { damage: 0, finishMethod: null };
  }

  let damage = Math.max(4, Math.round((successScore - defenseScore) * 0.55 + randomRange(3, 10)));
  damage += action.type === "grapple" ? randomInt(0, 3) : 0;
  defender.currentHealth = clamp(defender.currentHealth - damage, 0, 100);

  let finishMethod = null;
  if (action.type === "grapple" && defender.currentHealth < 18 && Math.random() < 0.36) {
    finishMethod = "SUB";
  } else if (defender.currentHealth < 14 && Math.random() < 0.5) {
    finishMethod = "KO/TKO";
  }

  const typeText = action.type === "strike" ? "celną akcję w stójce" : action.type === "grapple" ? "mocny atak w klinczu/parterze" : "dużą presję i kombinację";
  addFightLog(`${attackerName} trafia: ${typeText} (${damage} dmg).`);
  return { damage, finishMethod };
}

function simulateRound() {
  const player = career.fighter;
  const enemy = currentBout.opponent;

  addFightLog(`--- Runda ${currentRound} ---`);

  const playerFirst = (getFightStat(player, "stamina") + getFightStat(player, "defense") + randomInt(-8, 8))
    >= (enemy.stamina + enemy.defense + randomInt(-8, 8));

  const sequence = playerFirst
    ? [
        { attacker: player, defender: enemy, attackerName: "Ty", defenderName: "Rywal", side: "player" },
        { attacker: enemy, defender: player, attackerName: "Rywal", defenderName: "Ty", side: "enemy" }
      ]
    : [
        { attacker: enemy, defender: player, attackerName: "Rywal", defenderName: "Ty", side: "enemy" },
        { attacker: player, defender: enemy, attackerName: "Ty", defenderName: "Rywal", side: "player" }
      ];

  for (const exchange of sequence) {
    const result = resolveExchange(exchange.attacker, exchange.defender, exchange.attackerName, exchange.defenderName);
    if (exchange.side === "player") {
      currentBout.playerDamage += result.damage;
      if (exchange.defender.currentHealth <= 0) {
        currentBout.finishMethod = result.finishMethod || "KO/TKO";
        updateFightUI();
        return "player";
      }
    } else {
      currentBout.enemyDamage += result.damage;
      if (exchange.defender.currentHealth <= 0) {
        currentBout.finishMethod = result.finishMethod || "KO/TKO";
        updateFightUI();
        return "enemy";
      }
    }
    updateFightUI();
  }

  currentRound += 1;
  return null;
}

function judgeDecision() {
  const playerScore = currentBout.playerDamage * 1.7 + career.fighter.currentHealth * 0.6 + career.fighter.currentStamina * 0.18;
  const enemyScore = currentBout.enemyDamage * 1.7 + currentBout.opponent.currentHealth * 0.6 + currentBout.opponent.currentStamina * 0.18;
  if (Math.abs(playerScore - enemyScore) < 7) {
    return "draw";
  }
  return playerScore > enemyScore ? "player" : "enemy";
}

function startFight() {
  if (fightInterval) clearInterval(fightInterval);

  currentRound = 1;
  currentMaxRounds = currentBout.rounds;
  currentBout.playerDamage = 0;
  currentBout.enemyDamage = 0;
  currentBout.finishMethod = null;

  career.fighter.currentHealth = Math.min(100, career.fighter.currentHealth);
  career.fighter.currentStamina = Math.min(getFightStat(career.fighter, "stamina"), career.fighter.currentStamina + 10);
  currentBout.opponent.currentHealth = 100;
  currentBout.opponent.currentStamina = currentBout.opponent.stamina;

  if (fightLogElement) fightLogElement.innerHTML = "";

  showScreen("fight-screen");
  updateFightUI();

  addFightLog(`Start: ${currentBout.label} w ${getCurrentOrg().name}.`);
  addFightLog(`Obóz przygotowawczy: ${currentBout.camp ? currentBout.camp.name : "Standard Camp"}.`);
  addFightLog("Ty nie sterujesz walką — oglądasz efekt decyzji podejmowanych w karierze.");

  fightInterval = setInterval(() => {
    const winner = simulateRound();
    if (winner) {
      clearInterval(fightInterval);
      fightInterval = null;
      finishFight(winner);
      return;
    }
    if (currentRound > currentMaxRounds) {
      clearInterval(fightInterval);
      fightInterval = null;
      currentBout.finishMethod = "DEC";
      finishFight(judgeDecision());
    }
  }, 900);
}

function processRankingAndTitles(result) {
  const f = career.fighter;
  const org = getCurrentOrg();

  if (currentBout.type === "title-shot") {
    if (result === "player") {
      f.isChampion = true;
      f.rank = 1;
      f.currentTitleDefenses = 0;
      f.totalTitleWins += 1;
      career.titlesHistory.push(`${org.name} — zdobycie pasa`);
      addCareerLog(`Zdobywasz pas organizacji ${org.name}!`);
      addFightLog("Nowy mistrz!");
    } else if (result === "enemy") {
      f.rank = 1;
      addCareerLog("Przegrywasz walkę o pas, ale zostajesz w ścisłej czołówce.");
    } else {
      f.rank = 1;
      addCareerLog("Remis w walce o pas. Nadal jesteś bardzo blisko mistrzostwa.");
    }
    return;
  }

  if (currentBout.type === "title-defense") {
    if (result === "player") {
      f.currentTitleDefenses += 1;
      f.totalTitleDefenses += 1;
      career.titlesHistory.push(`${org.name} — obrona pasa #${f.currentTitleDefenses}`);
      addCareerLog(`Bronisz pasa organizacji ${org.name}.`);
    } else if (result === "enemy") {
      career.titlesHistory.push(`${org.name} — utrata pasa po ${f.currentTitleDefenses} obronach`);
      f.isChampion = false;
      f.rank = 1;
      f.currentTitleDefenses = 0;
      addCareerLog("Tracisz pas mistrzowski.");
    } else {
      addCareerLog("Remis w walce mistrzowskiej. Zachowujesz pas.");
    }
    return;
  }

  if (result === "player") {
    const jump = currentBout.type === "eliminator" ? randomInt(2, 3) : randomInt(1, 2);
    f.rank = Math.max(1, f.rank - jump);
    if (currentBout.type === "eliminator") {
      addCareerLog("Wygrywasz eliminator i zbliżasz się do title shota.");
    }
  } else if (result === "enemy") {
    const fall = currentBout.type === "eliminator" ? randomInt(1, 2) : 1;
    f.rank = Math.min(org.rankingSize, f.rank + fall);
  }
}

function maybeCreateInjury() {
  const f = career.fighter;
  let chance = 0.08;

  if (currentBout.finishMethod === "KO/TKO" && f.currentHealth < 22) chance += 0.1;
  if (f.currentHealth < 35) chance += 0.04;
  if (Math.random() > chance) return;

  const injuries = [
    { name: "Rozcięcie łuku brwiowego", weeks: 2 },
    { name: "Kontuzja kolana", weeks: 4 },
    { name: "Uraz dłoni", weeks: 3 },
    { name: "Kontuzja żeber", weeks: 3 }
  ];

  const injury = randomItem(injuries);
  career.injury = { name: injury.name, weeksLeft: injury.weeks };
  f.injuryCount += 1;
  addCareerLog(`Łapiesz kontuzję po walce: ${injury.name}. Pauza ${injury.weeks} tyg.`);
}

function applyFightDamageConsequences() {
  const f = career.fighter;
  f.currentHealth = Math.max(20, Math.floor(f.currentHealth));
  f.currentStamina = Math.max(18, Math.floor(f.currentStamina * 0.72));
  maybeCreateInjury();
}

function applyMethodRecord(result, finishMethod) {
  const f = career.fighter;
  const method = finishMethod || "DEC";

  if (result === "player") {
    if (method === "SUB") f.subWins += 1;
    else if (method === "DEC") f.decWins += 1;
    else f.koWins += 1;
  } else if (result === "enemy") {
    if (method === "SUB") f.subLosses += 1;
    else if (method === "DEC") f.decLosses += 1;
    else f.koLosses += 1;
  }
}

function applyFightPopularityAndFollowers(result) {
  const f = career.fighter;
  const managerPop = career.manager ? career.manager.popularityBonus : 0;
  const managerSocial = career.manager ? career.manager.socialBonus : 0;

  if (result === "player") {
    const popGainBase = currentBout.type === "regular" ? 4 : currentBout.type === "eliminator" ? 6 : 9;
    const popGain = Math.max(1, Math.round(popGainBase * (1 + managerPop)));
    f.popularity = clamp(f.popularity + popGain, 0, 100);
    let followersGain = randomInt(300, 950) + popGain * 90;
    if (currentBout.type === "title-shot" || currentBout.type === "title-defense") followersGain += 1200;
    f.followers += Math.round(followersGain * (1 + managerSocial));
    f.hype = clamp(f.hype + (currentBout.type === "regular" ? 3 : 6), 0, 100);
  } else if (result === "enemy") {
    f.popularity = clamp(f.popularity + (currentBout.type.includes("title") ? 1 : 0), 0, 100);
    f.followers += randomInt(40, 140);
    f.hype = Math.max(0, f.hype - 2);
  } else {
    f.popularity = clamp(f.popularity + 2, 0, 100);
    f.followers += randomInt(180, 420);
    f.hype = clamp(f.hype + 1, 0, 100);
  }
}

function getNetPayout(showMoney, winBonus, won) {
  const gross = showMoney + (won ? winBonus : 0);
  let managerCut = 0;

  if (career.manager) {
    managerCut = Math.round(gross * (career.manager.cutPercent / 100));
  }

  return { gross, managerCut, net: gross - managerCut };
}

function finishFight(result) {
  const f = career.fighter;
  const org = getCurrentOrg();
  const method = currentBout.finishMethod || "DEC";

  if (career.currentContract) {
    career.currentContract.fightsLeft -= 1;
  }

  const payout = getNetPayout(currentBout.showMoney, currentBout.winBonus, result === "player");
  f.money += payout.net;

  if (result === "player") {
    f.wins += 1;
    addFightLog(`Wynik: wygrywasz przez ${method}.`);
    addCareerLog(`Wygrywasz w ${org.name} przez ${method}. Inkaso netto: $${payout.net}.`);
  } else if (result === "enemy") {
    f.losses += 1;
    addFightLog(`Wynik: przegrywasz przez ${method}.`);
    addCareerLog(`Przegrywasz walkę w ${org.name} przez ${method}. Za sam występ wpada $${payout.net}.`);
  } else {
    f.draws += 1;
    addFightLog("Wynik: remis po decyzji.");
    addCareerLog(`Walczysz na remis w ${org.name}. Inkaso: $${payout.net}.`);
  }

  applyMethodRecord(result, method);
  applyFightPopularityAndFollowers(result);
  processRankingAndTitles(result);
  applyFightDamageConsequences();
  advanceWeek(1);

  if (career.currentContract && career.currentContract.fightsLeft <= 0) {
    addCareerLog("Kończy się Twój kontrakt. Czas wyjść na rynek kontraktowy.");
    career.currentContract = null;
  }

  career.nextFightCampId = "standard";
  updateCareerUI();

  setTimeout(() => {
    if (!career.retired) {
      showScreen("career-screen");
      currentBout = null;
    }
  }, 1500);

  checkCareerEndConditions();
}

function getCareerScore() {
  const f = career.fighter;
  return (
    f.wins * 3 +
    f.totalTitleWins * 18 +
    f.totalTitleDefenses * 8 +
    career.organizationsVisited.length * 6 +
    f.popularity / 4 +
    f.followers / 8000 +
    f.money / 2000 -
    f.losses * 1.5 -
    f.injuryCount * 2
  );
}

function getCareerRating(score) {
  if (score >= 130) return "Legenda MMA";
  if (score >= 95) return "Wielki mistrz";
  if (score >= 70) return "Top zawodnik";
  if (score >= 45) return "Bardzo solidna kariera";
  if (score >= 25) return "Solidny zawodnik";
  return "Niespełniony talent";
}

function retireCareer(reason) {
  if (career.retired) return;
  career.retired = true;

  if (fightInterval) {
    clearInterval(fightInterval);
    fightInterval = null;
  }

  const f = career.fighter;
  const org = getCurrentOrg();

  if (f.isChampion) {
    career.titlesHistory.push(`${org.name} — mistrz na koniec kariery, obrony: ${f.currentTitleDefenses}`);
    f.isChampion = false;
  }

  const score = getCareerScore();
  const rating = getCareerRating(score);

  setText("retire-reason", reason);
  setText("retire-rating", rating);
  setText("retire-record", `${f.wins}-${f.losses}-${f.draws}`);
  setText("retire-breakdown", `KO/TKO ${f.koWins}, SUB ${f.subWins}, DEC ${f.decWins}`);
  setText("retire-age", f.age);
  setText("retire-money", Math.floor(f.money));
  setText("retire-followers", Math.floor(f.followers));
  setText("retire-orgs", renderOrganizationsHistory());
  setText("retire-championships", f.totalTitleWins);
  setText("retire-defenses", f.totalTitleDefenses);
  setText("retire-weeks", f.weeksActive);
  setText("retire-belts", renderTitlesHistory());

  showScreen("retirement-screen");
}

function retireNow() {
  retireCareer("Sam decydujesz się zakończyć karierę.");
}

function checkCareerEndConditions() {
  const f = career.fighter;

  if (career.retired) return true;
  if (f.age >= 40) {
    retireCareer("Kończysz 40 lat i organizm nie pozwala już kontynuować kariery.");
    return true;
  }
  if (f.injuryCount >= 8) {
    retireCareer("Nagromadzenie urazów zmusza Cię do zakończenia kariery.");
    return true;
  }
  if (f.losses >= 20) {
    retireCareer("Zbyt wiele porażek kończy Twoją zawodową przygodę.");
    return true;
  }
  return false;
}

window.startCareer = startCareer;
window.trainStat = trainStat;
window.trainCardio = trainCardio;
window.restFighter = restFighter;
window.offerFight = offerFight;
window.acceptFight = acceptFight;
window.declineFight = declineFight;
window.scoutMarket = scoutMarket;
window.signContract = signContract;
window.closeContractMarket = closeContractMarket;
window.openManagerMarket = openManagerMarket;
window.hireManager = hireManager;
window.closeManagerMarket = closeManagerMarket;
window.socialAction = socialAction;
window.retireNow = retireNow;
window.selectCamp = selectCamp;

document.addEventListener("DOMContentLoaded", () => {
  initLogs();
  updateCareerUI();
  showScreen("menu-screen");
});
