MMA Career Simulator — wersja standalone bez CodePen

Pliki:
- index.html -> ekran startowy z przyciskiem Graj teraz
- game.html  -> sama gra
- style.css  -> wygląd strony i gry
- script.js  -> logika gry

Jak uruchomić:
1. Rozpakuj folder lub ZIP.
2. Otwórz index.html w przeglądarce.
3. Kliknij "Graj teraz".

Publikacja:
Możesz wrzucić cały folder na GitHub Pages, Netlify, Vercel albo Cloudflare Pages.
